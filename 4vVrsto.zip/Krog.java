import java.awt.Color;

//Razred Krog z atributi sredisce in barva ter konstruktorjem.// Razred pozicija z atributi x in y ter konstruktorjem
public class Krog {
	private Pozicija sredisce;
	private Color barva;
	
	public Krog(Pozicija sredisce, Color barva) {
		this.sredisce = sredisce;
		this.barva = barva;
	}

	// get in set metode za razred Krog
	public Pozicija getSredisce() {
		return sredisce;
	}

	public void setSredisce(Pozicija sredisce) {
		this.sredisce = sredisce;
	}

	public Color getBarva() {
		return barva;
	}

	public void setBarva(Color barva) {
		this.barva = barva;
	}
	
}
