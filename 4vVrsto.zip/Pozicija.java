// Razred pozicija z atributi x in y ter konstruktorjem
public class Pozicija {
	private int x;
	private int y;
	
	public Pozicija(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public Pozicija premakni(int x, int y) {
		return new Pozicija(getX() + x, getY() + y);
	}
	
	// get in set metode za atributa x in y.
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
}