import java.awt.*;
import java.util.*;
import java.util.List;

public class Igra {
	private Okno okno;
	private Krog[][] plosca;
	private Pozicija krogPozicija;
	private boolean prvi;
	private int jeZmagal; // 1 = rumeni, 2 = rdeči, 0 = ni zmagovalca.
	
	
	public Igra() {
		okno = new Okno(this);
		okno.setVisible(true);
		plosca = ustvariPlosco(6, 7);
		jeZmagal = 0;
	}

	
	public void igra(){
		setPrvi(true);
		while(true){
			if (krogPozicija != null) {
				krogPozicija = krogPozicija.premakni(0, 1); // povecujemo y koordinato
				boolean zastavica = false;
				// Preverjamo ce je krog na neki poziciji ki se ujema z pozicijo na plosci, sredisci se ujemeta ga narise
				for (int i = 0; i < 6; i++) {
					if (zastavica == true) {
						break;
					}
					for (int j = 0; j < 7; j++) {
						Krog mesto = plosca[i][j];
						if (krogPozicija.getY() == mesto.getSredisce().getY() &
							krogPozicija.getX() == mesto.getSredisce().getX()) {
							if (i < 5) {
								if (plosca[i + 1][j].getBarva() != null) {
									plosca[i][j].setBarva(isPrvi() ? Color.RED : Color.YELLOW);									
									krogPozicija = null;
									zastavica = true;
									break;
								}
							}
							else if (i == 5) {
								if (plosca[i][j].getBarva() == null) {
									plosca[i][j].setBarva(isPrvi() ? Color.RED : Color.YELLOW);
									krogPozicija = null;
									zastavica = true;
									break;
								}
							}
						}
					}
				}
			}
			zmagovalec();

			if (getJeZmagal() != 0) {
				if (getJeZmagal() == 2) {
					System.out.println("Rdec zmagovalec.");
				} else if (getJeZmagal() == 1) {
					System.out.println("Rumen zmagovalec.");
				}
				risi(); // Narise barvno zaveso
				try {
					Thread.sleep(2500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				resetiraj();
			}

			risi();
			
			if (jePolna()) {
				resetiraj();
			}
			
			try {
				Thread.sleep(1);
			}catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
		
	}
	
	// Seznam seznamov krogov, krogi in njihova sredisca 
	public Krog[][] ustvariPlosco(int st_vrstic, int st_stolpcev) {
		Krog[][] rezultat = new Krog[st_vrstic][st_stolpcev];
		int zamik = (int)Math.sqrt(Math.pow(25/2, 2)*2);
		for (int j = 0; j * 100 + 50 < 650; j++) {
			for (int i = 0; i * 100 + 50 < 750; i++) {
				rezultat[j][i] = new Krog(new Pozicija(i * 100 + 50 + zamik,j * 100 + 50 + zamik), null);
			}
		}
        return rezultat;
	}
	
	// Preverimo ali je plosca polna.
	public boolean jePolna() {
		for (int i = 0; i < getPlosca().length; i++) {
			for (int j = 0; j < getPlosca()[0].length; j ++) {
				if (getPlosca()[i][j].getBarva() == null) {
					return false;
				}
			}
		}
		return true;
	}
	
	// Resetiramo igro.
	public void resetiraj() {
		plosca = ustvariPlosco(6, 7);
		setPrvi(true);
		setJeZmagal(0);
	}
	
	// Na novo narisemo panelo.
	public void risi() {
		if(okno != null) {
			okno.repaint();
		}
	}
	
	// Menjava poteze
	public void naslednji() {
		prvi = !prvi;
	}
	
	// Getterji in setterji 
	public boolean isPrvi() {
		return prvi;
	}

	public void setPrvi(boolean prvi) {
		this.prvi = prvi;
	}

	public Okno getOkno() {
		return okno;
	}

	public void setOkno(Okno okno) {
		this.okno = okno;
	}

	public Krog[][] getPlosca() {
		return plosca;
	}

	public void setPlosca(Krog[][] plosca) {
		this.plosca = plosca;
	}

	public Pozicija getKrogPozicija() {
		return krogPozicija;
	}

	public void setKrogPozicija(Pozicija krogPozicija) {
		this.krogPozicija = krogPozicija;
	}
	//
	
	// Preverimo ali so v seznamu vrsta stiri elemnti barve Barva sosedni.
	public boolean vsebuje4(Color barva, List<Krog> vrsta) {
		int stevec = 0;
		if (vrsta.size() < 4) {
			return false;
		}
		for (int i = 0; i < vrsta.size(); i++) {

			if ((vrsta.get(i) == null ? null : vrsta.get(i).getBarva()) != barva) {
				stevec = 0;
			}

			else if ((vrsta.get(i) == null ? null : vrsta.get(i).getBarva()) == barva){
				stevec ++;
			}

			if (stevec == 4) {
				return true;
			}
		}
		return false;
	}
	// 
	
	//getterja in setterja
	public int getJeZmagal() {
		return jeZmagal;
	}

	public void setJeZmagal(int jeZmagal) {
		this.jeZmagal = jeZmagal;
	}
	
	// Generiramo sezname glede na stolpce, vrstice in diagonale in za vsak seznam preverimo vsebuje4 ce vsebuje 4 enake barve.
	public int zmagovalec(){
		// Vrstice
		for (int i = 0; i < getPlosca().length; i++) {
			if (vsebuje4(Color.YELLOW, Arrays.stream(plosca[i]).toList())) { // Pretvori array v list
				//return 1;
				System.out.println("Rumeni je zmagal!");
				setJeZmagal(1);
			}

			if (vsebuje4(Color.RED, Arrays.stream(plosca[i]).toList())) {
				//return 2;
				System.out.println("Rdeči je zmagal!");
				setJeZmagal(2);
			}

		}

		// Stolpci
		for (int i = 0; i < getPlosca()[0].length; i++) {

			List<Krog> vrsta = new ArrayList<>();

			for (int j = 0; j < getPlosca().length; j++) {
				vrsta.add(getPlosca()[j][i]);
			}

			if (vsebuje4(Color.YELLOW, vrsta)) {
				// return 1;
				System.out.println("Rumeni je zmagal!");
				setJeZmagal(1);
			}

			if (vsebuje4(Color.RED, vrsta)) {
				// return 2;
				System.out.println("Rdeči je zmagal!");
				setJeZmagal(2);
			}

		}

		// Desne diagonale
		// Modificiran zigzag algoritem.
		for (int lin = 1; lin < getPlosca()[0].length + getPlosca().length - 1; lin++) {
			int zacetni_stolpec = Math.max(0, lin - getPlosca().length);
			Set<Integer> elt = new HashSet<>(Arrays.asList(lin, (getPlosca()[0].length - zacetni_stolpec), getPlosca().length));
			int st_elt = Collections.min(elt);
			List<Krog> desnaDiagonala = new ArrayList<>();
			for (int j = 0; j < st_elt; j++) {
				desnaDiagonala.add(plosca[Math.min(getPlosca().length, lin) - j - 1][zacetni_stolpec + j]);
			}
			if (vsebuje4(Color.YELLOW, desnaDiagonala)) {
				// return 1;
				setJeZmagal(1);
			}
			else if (vsebuje4(Color.RED, desnaDiagonala)) {
				// return 2;
				setJeZmagal(2);
			}
		}

		// Leve diagonale
		for (int lin = 1; lin < getPlosca()[0].length + getPlosca().length; lin++) {
			int zacetni_stolpec = Math.max(0, getPlosca()[0].length - lin);
			Set<Integer> elt = new HashSet<>(Arrays.asList(lin, (getPlosca()[0].length - Math.max(0, lin - getPlosca().length)), getPlosca().length));
			int st_elt = Collections.min(elt);
			List<Krog> levaDiagonala = new ArrayList<>();
			for (int j = 0; j < st_elt; j++) {
				levaDiagonala.add(plosca[Math.max(0, lin - getPlosca()[0].length) + j][zacetni_stolpec + j]);
			}
			if (vsebuje4(Color.YELLOW, levaDiagonala)) {
				// return 1;
				setJeZmagal(1);
			}
			else if (vsebuje4(Color.RED, levaDiagonala)) {
				// return 2;
				setJeZmagal(2);
			}
		}

		return 0; // Ni zmagovalca.

	}
	
	//Main metoda
	public static void main(String[] args) {
      new Igra().igra();
    }
}
