import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class Okno extends JFrame {
	private Igra igra;
	
	public Okno(Igra igra) {
		super();
		this.igra = igra;
		setTitle("4 V VRSTO");
		setMinimumSize(new Dimension(800, 750));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new Panela(igra), BorderLayout.CENTER);
		
		// Meni 
		JMenuBar meniVrstica = new JMenuBar();
		setJMenuBar(meniVrstica);
		JMenu meni = new JMenu("Igra");
		JMenuItem p = new JMenuItem("Resetiraj"); //Gumb
		p.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				igra.resetiraj();
				
			}
		});
		meni.add(p);
		meniVrstica.add(meni);
		//
		
		pack();
	}
	
	// Get metoda za igro.
	public Igra getIgra() {
		return igra;
	}
}

