import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.util.HashSet;

import javax.swing.JPanel;

public class Panela extends JPanel{
	private Igra igra;
	public Panela(Igra igra) {
		super();
		this.igra = igra;
		setBackground(new Color(200,255,255));
		setFocusable(true); 
		
		addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			// Dogodek za klik miske.
			@Override
			public void mouseClicked(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();
				int zamik = (int)Math.sqrt(Math.pow(25/2, 2) * 2);
				if (x >= 50 & x < 150 ){ // Prvi stolpec
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][0].getBarva()); // Pogleda prvi stolpec
					}
					if (stolpec.contains(null)) { // Dodajamo zetone dokler imamo prazna mesta. (Stolpec se ni poln)
						if (igra.getKrogPozicija() == null) { // ce je ze prejsni zeton pado do konca
							igra.setKrogPozicija(new Pozicija(50 + zamik, 50));
							igra.naslednji(); 
						}
					}
				}
				else if (x >= 150 & x < 250 ){ //Drugi stolpec
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][1].getBarva());
					}
					if (stolpec.contains(null)) {
						if (igra.getKrogPozicija() == null) {
							igra.setKrogPozicija(new Pozicija(150 + zamik, 50));
							igra.naslednji();
						}
					}
				}
				else if (x >= 250 & x < 350 ){ //Tretji stolpec
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][2].getBarva());
					}
					if (stolpec.contains(null)) {
						if (igra.getKrogPozicija() == null) {
							igra.setKrogPozicija(new Pozicija(250 + zamik, 50));
							igra.naslednji();
						}
					}
				}
				else if (x >= 350 & x < 450 ){ // Cetrti stolpec
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][3].getBarva());
					}
					if (stolpec.contains(null)) {
						if (igra.getKrogPozicija() == null) {
							igra.setKrogPozicija(new Pozicija(350 + zamik, 50));
							igra.naslednji();
						}
					}
				}
				else if (x >= 450 & x < 550 ){ // Peti 
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][4].getBarva());
					}
					if (igra.getKrogPozicija() == null) {
						igra.setKrogPozicija(new Pozicija(450 + zamik, 50));
						igra.naslednji();
					}
				}
				else if (x >= 550 & x < 650 ){ // Sesti
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][5].getBarva());
					}
					if (stolpec.contains(null)) {
						if (igra.getKrogPozicija() == null) {
							igra.setKrogPozicija(new Pozicija(550 + zamik, 50));
							igra.naslednji();
						}
					}
				}
				else if (x >= 650 & x < 750 ){ // Sedmi
					HashSet<Color> stolpec = new HashSet<>();
					for (int j = 0; j < igra.getPlosca().length; j++) {
						stolpec.add(igra.getPlosca()[j][6].getBarva());
					}
					if (stolpec.contains(null)) {
						if (igra.getKrogPozicija() == null) {
							igra.setKrogPozicija(new Pozicija(650 + zamik, 50));
							igra.naslednji();
						}
					}
				}
			}
		});
	}	
	//
	
    @Override
    public void paint(Graphics g){
        super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
        int x0 = 50;
        int y0 = 50;
        int radij = 75;
        int size = 100;
        int zamik = (int)Math.sqrt(Math.pow((size - radij)/2, 2)*2);
        // Risemo zetone.
        for (int j = 0; j < igra.getPlosca().length;j++) { // Skozi vrstice 
            for (int i = 0; i < igra.getPlosca()[0].length;i++) { // Skozi stolpce
            	Krog krog = igra.getPlosca()[j][i];	
            	if (krog.getBarva() != null) {
	            	g.setColor(krog.getBarva());
	            	int x = krog.getSredisce().getX();
	            	int y = krog.getSredisce().getY();
	            	g.fillOval(x, y, radij,radij);
            	}

            }
        }
        
        // Izris kroga ko se premika oz. pad
		if (igra.getKrogPozicija() != null) {
			g.setColor(igra.isPrvi() ? Color.RED : Color.YELLOW);
			g.fillOval(igra.getKrogPozicija().getX(), igra.getKrogPozicija().getY(), 75, 75);
		}
		
		// Izrisujemo plosco.
		g2d.setColor(new Color(0, 0, 153));
		Area a = new Area(new Rectangle(x0, y0, 700, 600));
		for (int i = x0; i < 600 + y0; i = i + size) {
			for (int j = y0; j < 700 + x0; j = j + size) {
				a.subtract(new Area(new Ellipse2D.Double(j + zamik, i + zamik, radij, radij)));
			}
		}
		// Barva zavesa ko imamo zmagovalca.
		g2d.fill(a);
		if (igra.getJeZmagal() != 0) {
			Color barva = igra.getJeZmagal() == 1 ? new Color(255, 255, 0, 150)  : new Color(255, 0, 0, 150);
			g.setColor(barva);
			g.fillRect(0, 0, getWidth(), getHeight());
		}
    }
    
    // Get metoda za igro
	public Igra getIgra() {
		return igra;
	}
}
